SAVINGS CHALLENGE - ANDROID STUDIO PROJECT

This is an installable Android app project containing the offline savings tracker.
The tracker records the date when you tap a ₹100 or ₹500 box and stores progress
locally on the device using WebView local storage.

BUILD AN APK
1. Install Android Studio on a computer.
2. Open Android Studio and choose "Open".
3. Select the extracted SavingsChallengeAndroid folder.
4. Allow Gradle sync and install Android SDK Platform 35 if prompted.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio will show the APK location. Transfer the APK to your phone
   and install it. You may need to allow installation from that source.

IMPORTANT
- This is an offline, single-device app; no bank connection or automatic money
  transfer is performed. You must transfer savings yourself.
- Your savings history is stored on the phone. Clearing app data or uninstalling
  the app can erase it. Use Export history in the tracker to keep a backup.
- Package name: com.debabrata.savingschallenge
